#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
	int iRet = 0;
	int iSocket = -1;
	int iClientFd = -1;
	int iTcpPort = 0;
	char *pcTcpAddr = NULL;
	static unsigned int suiNo = 0; 
	socklen_t stCliAddrLen = 0;
	struct sockaddr_in stCliAddr;
	fd_set stFdSet, stReadFdSet;
	char *arrDataBuff[1024] = {0};
	struct timeval stTv;
	
	if(3 != argc){
		cout << "Usage :\n  cli <ip_addr> <port>" << endl;
		return -1;
	}
	else{
		iTcpPort = atoi(argv[2]);
		pcTcpAddr = argv[1];
	}
	
	iSocket = socket(AF_INET, SOCK_STREAM, 0);
	if(-1 == iSocket){
		cout << "Socket error!" << endl;
		return -1;
	}
	
	bool bReuseaddr = true;
	setsockopt(iSocket, SOL_SOCKET, SO_REUSEADDR, (char *)&bReuseaddr, sizeof(bool));
	setsockopt(iSocket,IPPROTO_TCP, TCP_NODELAY, (char *)&bReuseaddr, sizeof(bool));	
	
	stTv.tv_sec = 2;
	stTv.tv_usec = 0;
	setsockopt(iSocket, SOL_SOCKET, SO_SNDTIMEO, (char *)&stTv, sizeof(stTv));
	
	struct linger stLinger;
	stLinger.l_onoff = 1;
	stLinger.l_linger = 0;
	setsockopt(iSocket, SOL_SOCKET, SO_LINGER, (char *)&stLinger, sizeof(struct linger));
	
	stCliAddr.sin_family = AF_INET;
	stCliAddr.sin_port = htons(iTcpPort);
	stCliAddr.sin_addr.s_addr = inet_addr(pcTcpAddr);
	if(0 != connect(iSocket, (sockaddr *)&stCliAddr, sizeof(stCliAddr))){
		cout << "Connect error!" << endl;
		return -1;
	}
	
	FD_ZERO(&stFdSet);
	FD_SET(iSocket, &stFdSet);	

	while(true){
		stTv.tv_sec = 5;
		stTv.tv_usec = 0;	
		stReadFdSet = stFdSet;	
		iRet = select(iSocket+1, &stReadFdSet, NULL, NULL, &stTv);
		cout << "iRet = " << iRet << endl;
		if(0 >= iRet){
			continue;
		} 
	
		memset(arrDataBuff, 0x00, sizeof(arrDataBuff));
		iRet = read(iSocket, arrDataBuff, sizeof(arrDataBuff));		
		if(0 > iRet){
			cout << "Read error!" << endl;
			close(iSocket);
		}
		else if(0 == iRet){
			
		}
		else{			
			iRet = write(iSocket, arrDataBuff, sizeof(arrDataBuff));
			if(iRet < 0){
				cout << "Write error!" << endl;
			}
		}		
	}
	
	getchar();
	close(iSocket);
	
	return 0;	
}